--------------------------------------------------------
--  Fichier cr�� - mardi-mai-10-2022   
--------------------------------------------------------
DROP TABLE "AMIR"."AGENCES" cascade constraints;
DROP TABLE "AMIR"."CLIENTS" cascade constraints;
DROP TABLE "AMIR"."COMPTE" cascade constraints;
DROP TABLE "AMIR"."COMPTES" cascade constraints;
DROP TABLE "AMIR"."CONTRATS" cascade constraints;
DROP TABLE "AMIR"."EMPLOYE" cascade constraints;
DROP TABLE "AMIR"."EMPLOYES" cascade constraints;
DROP TABLE "AMIR"."EMPLOYESCLIENTS" cascade constraints;
DROP TABLE "AMIR"."EVALUATION" cascade constraints;
DROP TABLE "AMIR"."PRODUITS" cascade constraints;
--------------------------------------------------------
--  DDL for Table AGENCES
--------------------------------------------------------

  CREATE TABLE "AMIR"."AGENCES" 
   (	"NUMAGENCE" NUMBER, 
	"NOMAGENCE" VARCHAR2(20 BYTE), 
	"VILLE" VARCHAR2(20 BYTE), 
	"NUMTELA" VARCHAR2(20 BYTE), 
	"ADRESSEA" VARCHAR2(100 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table CLIENTS
--------------------------------------------------------

  CREATE TABLE "AMIR"."CLIENTS" 
   (	"CIN" NUMBER, 
	"NOMCL" VARCHAR2(20 BYTE), 
	"PRENOMCL" VARCHAR2(20 BYTE), 
	"EMAILCL" VARCHAR2(100 BYTE), 
	"TYPECL" VARCHAR2(20 BYTE), 
	"NUMTELCL" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table COMPTE
--------------------------------------------------------

  CREATE TABLE "AMIR"."COMPTE" 
   (	"PWD" VARCHAR2(20 BYTE), 
	"LOGIN" VARCHAR2(20 BYTE), 
	"IDEMP" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table COMPTES
--------------------------------------------------------

  CREATE TABLE "AMIR"."COMPTES" 
   (	"MDP" VARCHAR2(20 BYTE), 
	"NOMUTILISATEUR" VARCHAR2(20 BYTE), 
	"IDE" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table CONTRATS
--------------------------------------------------------

  CREATE TABLE "AMIR"."CONTRATS" 
   (	"NUMCONTRAT" NUMBER, 
	"TYPEC" VARCHAR2(20 BYTE), 
	"CONTENU" VARCHAR2(4000 BYTE), 
	"IMAGEQR" VARCHAR2(100 BYTE), 
	"DATEC" DATE, 
	"CIN" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table EMPLOYE
--------------------------------------------------------

  CREATE TABLE "AMIR"."EMPLOYE" 
   (	"IDEMP" NUMBER, 
	"NOM" VARCHAR2(20 BYTE), 
	"PRENOM" VARCHAR2(20 BYTE), 
	"NUM_TEL" VARCHAR2(20 BYTE), 
	"SALAIRE" VARCHAR2(20 BYTE), 
	"ROLE" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table EMPLOYES
--------------------------------------------------------

  CREATE TABLE "AMIR"."EMPLOYES" 
   (	"IDE" NUMBER, 
	"NOME" VARCHAR2(20 BYTE), 
	"PRENOME" VARCHAR2(20 BYTE), 
	"ADRESSEE" VARCHAR2(100 BYTE), 
	"NUMTEL" VARCHAR2(20 BYTE), 
	"EMAILE" VARCHAR2(100 BYTE), 
	"ROLE" VARCHAR2(20 BYTE), 
	"NUMAGENCE" NUMBER, 
	"UID_RFID" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table EMPLOYESCLIENTS
--------------------------------------------------------

  CREATE TABLE "AMIR"."EMPLOYESCLIENTS" 
   (	"IDE" NUMBER, 
	"CIN" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table EVALUATION
--------------------------------------------------------

  CREATE TABLE "AMIR"."EVALUATION" 
   (	"NOTE" VARCHAR2(20 BYTE), 
	"DATEN" DATE DEFAULT SYSDATE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table PRODUITS
--------------------------------------------------------

  CREATE TABLE "AMIR"."PRODUITS" 
   (	"ID_PRODUIT" NUMBER, 
	"TYPE_PRODUIT" VARCHAR2(20 BYTE), 
	"ADRESSE" VARCHAR2(100 BYTE), 
	"DESCRIPTION" VARCHAR2(4000 BYTE), 
	"IMAGE" VARCHAR2(100 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into AMIR.AGENCES
SET DEFINE OFF;
Insert into AMIR.AGENCES (NUMAGENCE,NOMAGENCE,VILLE,NUMTELA,ADRESSEA) values ('1','homepad','tunis','23456756','DFXCGHVBJKNLJHG');
Insert into AMIR.AGENCES (NUMAGENCE,NOMAGENCE,VILLE,NUMTELA,ADRESSEA) values ('11','rqezrza','rezar','12345678','arze');
REM INSERTING into AMIR.CLIENTS
SET DEFINE OFF;
Insert into AMIR.CLIENTS (CIN,NOMCL,PRENOMCL,EMAILCL,TYPECL,NUMTELCL) values ('986545','boudidah','amir','amirboudidah@gmail.com',null,'9032256');
Insert into AMIR.CLIENTS (CIN,NOMCL,PRENOMCL,EMAILCL,TYPECL,NUMTELCL) values ('667788','AMENI','drira','huhu@dyhu',null,'678U8I89');
REM INSERTING into AMIR.COMPTE
SET DEFINE OFF;
Insert into AMIR.COMPTE (PWD,LOGIN,IDEMP) values ('admin','admin','567');
Insert into AMIR.COMPTE (PWD,LOGIN,IDEMP) values ('123','yessine','1');
Insert into AMIR.COMPTE (PWD,LOGIN,IDEMP) values ('123','ousmaa','22');
REM INSERTING into AMIR.COMPTES
SET DEFINE OFF;
Insert into AMIR.COMPTES (MDP,NOMUTILISATEUR,IDE) values ('12345','amir','1');
Insert into AMIR.COMPTES (MDP,NOMUTILISATEUR,IDE) values ('12345','eya','2');
REM INSERTING into AMIR.CONTRATS
SET DEFINE OFF;
Insert into AMIR.CONTRATS (NUMCONTRAT,TYPEC,CONTENU,IMAGEQR,DATEC,CIN) values ('124356','achat','
Entre les soussign??s:

Le vendeur 
Monsieur/Madame boudidah amir 
ayant la carte d???identit?? n?? 986545

Et

L''acqu??reur 
HomePad

IL A ??T?? FAIT ET CONVENU CE QUI SUIT 
Le vendeur, par ces pr??sentes, en s''obligeant ?? toutes les garanties ordinaires de fait et de droit, vend, 
sous les conditions suspensives ci-apr??s ??nonc??es, ?? L''acqu??reur qui accepte pour lui-m??me ou toute personne
physique ou morale qu''il se substituera ?? titre gratuit, en totalit??, en pleine propri??t?? et en toute hypoth??se 
avant la r??alisation de toutes les conditions suspensives, mais dont il sera solidairement garant, 
ce qui est accept?? par le vendeur, le bien immobilier ci-apr??s d??sign??, que l''acqu??reur d??clare bien conna??tre 
pour l''avoir vu et visit??

INFORMATION PR??ALABLE DES PARTIES
Les parties reconnaissent avoir ??t?? inform??es des cons??quences pouvant r??sulter de l''application de L???article 1112-1
du Code civil dont les dispositions sont litt??ralement reproduites au-dessous: "Celle des parties qui conna??t 
une information dont l''importance est d??terminante pour le consentement de T''autre doit l''en informer d??s lors que, 
l??gitimement, cette derni??re ignore cette information ou fait confiance ?? son cocontractant N??anmoins, 
ce devoir d''information ne porte pas sur l''estimation de la valeur de la prestation Ont une importance d??terminante 
les informations qui ont un lien direct et n??cessaire avec le contenu du contrat ou la qualit?? des parties. 
Il incombe ?? celui qui pr??tend qu''une information lui ??tait due de prouver que l''autre partie la lui devait, 
?? charge pour cette autre partie de prouver qu''elle l''a fournie Les parties ne peuvent ni limiter ni exclure ce devoir. 
Outre la responsabilit?? de celui qui en ??tait tenu, le manquement ?? ce devoir d''information peut entra??ner l''annulation 
du contrat dans les conditions pr??vues aux articles 1130 .
PRIX-INDEMNIT??S D''IMMOBILISATION
Prix et versement par l''acqu??reur La pr??sente vente, soumise aux droits d''enregistrement que l''acqu??reur acquittera 
en sus du prix le jour de la signature de l''acte authentique, est consentie et accept??e moyennant le prix principal de 100,000 TND .
L''acqu??reur acquittera en outre, et dans tous les cas, tous les frais, droits et ??moluments de l''acte authentique qui constatera 
la r??alisation de la vente.


signature du vendeur 							signature du l''acqu??reur 
______ 								______ 
			
Date 
01/02/2000','C:/Users/amirb/Desktop/project/HomePad/qrcode_124356.png',to_date('01/02/00','DD/MM/RR'),'986545');
Insert into AMIR.CONTRATS (NUMCONTRAT,TYPEC,CONTENU,IMAGEQR,DATEC,CIN) values ('11','achat','
Entre les soussign??s:

Le vendeur 
Monsieur/Madame boudidah amir 
ayant la carte d???identit?? n?? 1

Et

L''acqu??reur 
HomePad

IL A ??T?? FAIT ET CONVENU CE QUI SUIT 
Le vendeur, par ces pr??sentes, en s''obligeant ?? toutes les garanties ordinaires de fait et de droit, vend, 
sous les conditions suspensives ci-apr??s ??nonc??es, ?? L''acqu??reur qui accepte pour lui-m??me ou toute personne
physique ou morale qu''il se substituera ?? titre gratuit, en totalit??, en pleine propri??t?? et en toute hypoth??se 
avant la r??alisation de toutes les conditions suspensives, mais dont il sera solidairement garant, 
ce qui est accept?? par le vendeur, le bien immobilier ci-apr??s d??sign??, que l''acqu??reur d??clare bien conna??tre 
pour l''avoir vu et visit??

INFORMATION PR??ALABLE DES PARTIES
Les parties reconnaissent avoir ??t?? inform??es des cons??quences pouvant r??sulter de l''application de L???article 1112-1
du Code civil dont les dispositions sont litt??ralement reproduites au-dessous: "Celle des parties qui conna??t 
une information dont l''importance est d??terminante pour le consentement de T''autre doit l''en informer d??s lors que, 
l??gitimement, cette derni??re ignore cette information ou fait confiance ?? son cocontractant N??anmoins, 
ce devoir d''information ne porte pas sur l''estimation de la valeur de la prestation Ont une importance d??terminante 
les informations qui ont un lien direct et n??cessaire avec le contenu du contrat ou la qualit?? des parties. 
Il incombe ?? celui qui pr??tend qu''une information lui ??tait due de prouver que l''autre partie la lui devait, 
?? charge pour cette autre partie de prouver qu''elle l''a fournie Les parties ne peuvent ni limiter ni exclure ce devoir. 
Outre la responsabilit?? de celui qui en ??tait tenu, le manquement ?? ce devoir d''information peut entra??ner l''annulation 
du contrat dans les conditions pr??vues aux articles 1130 .
PRIX-INDEMNIT??S D''IMMOBILISATION
Prix et versement par l''acqu??reur La pr??sente vente, soumise aux droits d''enregistrement que l''acqu??reur acquittera 
en sus du prix le jour de la signature de l''acte authentique, est consentie et accept??e moyennant le prix principal de 100,000 TND .
L''acqu??reur acquittera en outre, et dans tous les cas, tous les frais, droits et ??moluments de l''acte authentique qui constatera 
la r??alisation de la vente.


signature du vendeur 							signature du l''acqu??reur 
______ 								______ 
			
Date 
01/01/2000','C:/Users/amirb/Desktop/project/HomePad/qrcodes/qrcode_11.png',to_date('01/01/00','DD/MM/RR'),'1');
REM INSERTING into AMIR.EMPLOYE
SET DEFINE OFF;
Insert into AMIR.EMPLOYE (IDEMP,NOM,PRENOM,NUM_TEL,SALAIRE,ROLE) values ('22','romdhani','oussema','55443221','1591','employe');
Insert into AMIR.EMPLOYE (IDEMP,NOM,PRENOM,NUM_TEL,SALAIRE,ROLE) values ('13','argoubi','soumaya','54332666','5050','gerant');
Insert into AMIR.EMPLOYE (IDEMP,NOM,PRENOM,NUM_TEL,SALAIRE,ROLE) values ('135','agrebi','lotfi','5433244','4040','gerant');
Insert into AMIR.EMPLOYE (IDEMP,NOM,PRENOM,NUM_TEL,SALAIRE,ROLE) values ('567','admin','admin','456789','5151','gerant');
Insert into AMIR.EMPLOYE (IDEMP,NOM,PRENOM,NUM_TEL,SALAIRE,ROLE) values ('1','romdhani','yessine','23456','188','gerant');
REM INSERTING into AMIR.EMPLOYES
SET DEFINE OFF;
Insert into AMIR.EMPLOYES (IDE,NOME,PRENOME,ADRESSEE,NUMTEL,EMAILE,ROLE,NUMAGENCE,UID_RFID) values ('1','boudidah','amir','ezzahra','90322256','amir.bou@esprit.tn','employe','1',' 3B 11 69 1B');
Insert into AMIR.EMPLOYES (IDE,NOME,PRENOME,ADRESSEE,NUMTEL,EMAILE,ROLE,NUMAGENCE,UID_RFID) values ('2','mosbeh','eya','Mornag','1543798','jhbjvj','employe','1',null);
Insert into AMIR.EMPLOYES (IDE,NOME,PRENOME,ADRESSEE,NUMTEL,EMAILE,ROLE,NUMAGENCE,UID_RFID) values ('3','blanco','yessine','gfdh','6746465','dfcwdxf','gerant','1',null);
REM INSERTING into AMIR.EMPLOYESCLIENTS
SET DEFINE OFF;
REM INSERTING into AMIR.EVALUATION
SET DEFINE OFF;
Insert into AMIR.EVALUATION (NOTE,DATEN) values ('non satisfait',to_date('26/04/22','DD/MM/RR'));
Insert into AMIR.EVALUATION (NOTE,DATEN) values ('satisfait',to_date('26/04/22','DD/MM/RR'));
Insert into AMIR.EVALUATION (NOTE,DATEN) values ('satisfait',to_date('26/04/22','DD/MM/RR'));
Insert into AMIR.EVALUATION (NOTE,DATEN) values ('non satisfait',to_date('26/04/22','DD/MM/RR'));
REM INSERTING into AMIR.PRODUITS
SET DEFINE OFF;
Insert into AMIR.PRODUITS (ID_PRODUIT,TYPE_PRODUIT,ADRESSE,DESCRIPTION,IMAGE) values ('1525','VILLA','RAS JBAL','GRANDSURFACE',null);
Insert into AMIR.PRODUITS (ID_PRODUIT,TYPE_PRODUIT,ADRESSE,DESCRIPTION,IMAGE) values ('2111','TERRAIN','EZZAHRA','S',null);
Insert into AMIR.PRODUITS (ID_PRODUIT,TYPE_PRODUIT,ADRESSE,DESCRIPTION,IMAGE) values ('1244','VILLA','EZZAHRA','S',null);
--------------------------------------------------------
--  DDL for Index AGENCES_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "AMIR"."AGENCES_PK" ON "AMIR"."AGENCES" ("NUMAGENCE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index CLIENTS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "AMIR"."CLIENTS_PK" ON "AMIR"."CLIENTS" ("CIN") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index COMPTES_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "AMIR"."COMPTES_PK" ON "AMIR"."COMPTES" ("IDE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index EMPLOYE_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "AMIR"."EMPLOYE_PK" ON "AMIR"."EMPLOYE" ("IDEMP") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index EMPLOYESCLIENTS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "AMIR"."EMPLOYESCLIENTS_PK" ON "AMIR"."EMPLOYESCLIENTS" ("IDE", "CIN") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index EMPLOYES_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "AMIR"."EMPLOYES_PK" ON "AMIR"."EMPLOYES" ("IDE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index PRODUITS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "AMIR"."PRODUITS_PK" ON "AMIR"."PRODUITS" ("ID_PRODUIT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table AGENCES
--------------------------------------------------------

  ALTER TABLE "AMIR"."AGENCES" MODIFY ("NUMAGENCE" NOT NULL ENABLE);
  ALTER TABLE "AMIR"."AGENCES" ADD CONSTRAINT "AGENCES_PK" PRIMARY KEY ("NUMAGENCE")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
--------------------------------------------------------
--  Constraints for Table CLIENTS
--------------------------------------------------------

  ALTER TABLE "AMIR"."CLIENTS" MODIFY ("CIN" NOT NULL ENABLE);
  ALTER TABLE "AMIR"."CLIENTS" ADD CONSTRAINT "CLIENTS_PK" PRIMARY KEY ("CIN")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
--------------------------------------------------------
--  Constraints for Table COMPTES
--------------------------------------------------------

  ALTER TABLE "AMIR"."COMPTES" ADD CONSTRAINT "COMPTES_PK" PRIMARY KEY ("IDE")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "AMIR"."COMPTES" MODIFY ("IDE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table EMPLOYE
--------------------------------------------------------

  ALTER TABLE "AMIR"."EMPLOYE" ADD CONSTRAINT "EMPLOYE_PK" PRIMARY KEY ("IDEMP")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "AMIR"."EMPLOYE" MODIFY ("IDEMP" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table EMPLOYES
--------------------------------------------------------

  ALTER TABLE "AMIR"."EMPLOYES" MODIFY ("IDE" NOT NULL ENABLE);
  ALTER TABLE "AMIR"."EMPLOYES" ADD CONSTRAINT "EMPLOYES_PK" PRIMARY KEY ("IDE")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
--------------------------------------------------------
--  Constraints for Table EMPLOYESCLIENTS
--------------------------------------------------------

  ALTER TABLE "AMIR"."EMPLOYESCLIENTS" MODIFY ("CIN" NOT NULL ENABLE);
  ALTER TABLE "AMIR"."EMPLOYESCLIENTS" MODIFY ("IDE" NOT NULL ENABLE);
  ALTER TABLE "AMIR"."EMPLOYESCLIENTS" ADD CONSTRAINT "EMPLOYESCLIENTS_PK" PRIMARY KEY ("IDE", "CIN")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
--------------------------------------------------------
--  Constraints for Table PRODUITS
--------------------------------------------------------

  ALTER TABLE "AMIR"."PRODUITS" MODIFY ("ID_PRODUIT" NOT NULL ENABLE);
  ALTER TABLE "AMIR"."PRODUITS" ADD CONSTRAINT "PRODUITS_PK" PRIMARY KEY ("ID_PRODUIT")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table COMPTES
--------------------------------------------------------

  ALTER TABLE "AMIR"."COMPTES" ADD CONSTRAINT "COMPTES_FK1" FOREIGN KEY ("IDE")
	  REFERENCES "AMIR"."EMPLOYES" ("IDE") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table EMPLOYES
--------------------------------------------------------

  ALTER TABLE "AMIR"."EMPLOYES" ADD CONSTRAINT "EMPLOYES_FK1" FOREIGN KEY ("NUMAGENCE")
	  REFERENCES "AMIR"."AGENCES" ("NUMAGENCE") ON DELETE CASCADE DISABLE;
--------------------------------------------------------
--  Ref Constraints for Table EMPLOYESCLIENTS
--------------------------------------------------------

  ALTER TABLE "AMIR"."EMPLOYESCLIENTS" ADD CONSTRAINT "EMPLOYESCLIENTS_FK1" FOREIGN KEY ("IDE")
	  REFERENCES "AMIR"."EMPLOYES" ("IDE") ON DELETE CASCADE ENABLE;
  ALTER TABLE "AMIR"."EMPLOYESCLIENTS" ADD CONSTRAINT "EMPLOYESCLIENTS_FK2" FOREIGN KEY ("CIN")
	  REFERENCES "AMIR"."CLIENTS" ("CIN") ON DELETE CASCADE ENABLE;
